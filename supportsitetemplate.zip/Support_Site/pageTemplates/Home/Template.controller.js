sap.ui.controller("cpv2.templates.Home.Template", {

	onInit: function() {}
});