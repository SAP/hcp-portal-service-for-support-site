sap.ui.controller("cpv2.templates.4_Sections.Template", {

	onInit: function() {

	}
});